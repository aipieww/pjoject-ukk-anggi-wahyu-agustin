<?php
include '../login/config.php';
session_start();


if (!isset($_SESSION['user']) || $_SESSION['user'] != 'siswa') {
    header('Location: ../login/index.php');
    exit;
}

$id_anggota = $_SESSION['id_anggota'];
$nama = $_SESSION['nama'];


$total_buku = 0;
$total_stok = 0;
$peminjaman_aktif = 0;


$query_buku = "SELECT COUNT(*) as total FROM buku";
$result_buku = mysqli_query($conn, $query_buku);
if ($result_buku && mysqli_num_rows($result_buku) > 0) {
    $row_buku = mysqli_fetch_assoc($result_buku);
    $total_buku = $row_buku['total'];
}


$query_stok = "SELECT SUM(stok) as total FROM buku";
$result_stok = mysqli_query($conn, $query_stok);
if ($result_stok && mysqli_num_rows($result_stok) > 0) {
    $row_stok = mysqli_fetch_assoc($result_stok);
    $total_stok = $row_stok['total'] ?? 0;
}


$query_aktif = "SELECT COUNT(*) as total FROM peminjaman WHERE id_anggota = $id_anggota AND status = 'dipinjam'";
$result_aktif = mysqli_query($conn, $query_aktif);
if ($result_aktif && mysqli_num_rows($result_aktif) > 0) {
    $row_aktif = mysqli_fetch_assoc($result_aktif);
    $peminjaman_aktif = $row_aktif['total'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Lumina Archive</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    

    
    <div class="sidebar">
        <h2>Lumina Archive</h2>
        <a href="dashboard.php?page=home">Home</a>
        <a href="koleksi_buku.php">Koleksi Buku</a>
        <a href="laporan.php">Laporan</a>
        <a href="../login/logout.php">Logout</a>
    </div>

    <div class="content">
        <?php
        $page = isset($_GET['page']) ? $_GET['page'] : 'home';

        if ($page == 'home') {
        ?>

    <header class="topbar">
<span>
                   <h1>Selamat Datang,<br><?php echo $nama; ?>!</h1>
                </span>
                
                 <search>
            <input id="searchInput" type="text" placeholder="Cari buku..." oninput="searchBooks()">
           
            
        </search>

        

    </header>

        

            <div class="stats">
                <div class="stat">
                    <h3>Total Buku</h3>
                    <p><?php echo $total_buku; ?></p>
                </div>
                <div class="stat">
                    <h3>Total Stok</h3>
                    <p><?php echo $total_stok; ?></p>
                </div>
                <div class="stat">
                    <h3>Peminjaman Aktif</h3>
                    <p><?php echo $peminjaman_aktif; ?></p>
                </div>
            </div>

            <h2>Buku Tersedia</h2>
            <div class="cards">
                <?php
                $query_buku_tersedia = "SELECT * FROM buku WHERE stok > 0 ORDER BY judul_buku ASC";
                $result_buku_tersedia = mysqli_query($conn, $query_buku_tersedia);

                if ($result_buku_tersedia && mysqli_num_rows($result_buku_tersedia) > 0) {
                    while ($row = mysqli_fetch_assoc($result_buku_tersedia)) {
                        $cover_path = $row['cover'] ? '../assets/cover/' . $row['cover'] : 'https://via.placeholder.com/180x150?text=No+Cover';
                        $bukuData = json_encode([
                            'judul' => $row['judul_buku'],
                            'pengarang' => $row['pengarang'],
                            'penerbit' => $row['penerbit'],
                            'tahun' => $row['tahun_terbit'],
                            'stok' => $row['stok'],
                            'sinopsis' => $row['sinopsis'] ?? '',
                            'cover' => $cover_path,
                            'id' => $row['id_buku']
                        ]);
                ?>
                <div class="card" onclick="openBookDetail(this)" data-book='<?php echo htmlspecialchars($bukuData, ENT_QUOTES, 'UTF-8'); ?>' style="cursor: pointer;">
                    <img src="<?php echo $cover_path; ?>" alt="<?php echo $row['judul_buku']; ?>">
                    <h4><?php echo substr($row['judul_buku'], 0, 18); ?></h4>
                    <p><strong><?php echo $row['pengarang']; ?></strong></p>
                    <p>Stok: <span style="color: #f18282; font-weight: bold;"><?php echo $row['stok']; ?></span></p>
                    <a href="koleksi_buku.php?pinjam=<?php echo $row['id_buku']; ?>" class="btn-pinjam">Pinjam</a>
                </div>

                
                <?php
                
                    }
                } else {
                    echo "<p style='color: #999;'>Belum ada buku tersedia</p>";
                }
                ?>
            </div>
        <?php } ?>
    </div>

    <!-- Book Detail Modal -->
    <div id="bookDetailModal">
        <div class="book-detail-container">
            <div class="book-detail-cover">
                <img id="bookCover" src="" alt="Book Cover">
            </div>
            <div class="book-detail-info">
                <h2 id="bookTitle">-</h2>
                <div class="detail-item">
                    <div class="detail-label">Pengarang</div>
                    <div class="detail-value" id="bookAuthor">-</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Penerbit</div>
                    <div class="detail-value" id="bookPublisher">-</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Tahun Terbit</div>
                    <div class="detail-value" id="bookYear">-</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Stok Tersedia</div>
                    <div class="detail-value" id="bookStock">-</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Deskripsi</div>
                    <div class="book-detail-synopsis" id="bookSynopsis">-</div>
                </div>
                <div class="book-detail-actions">
                    <button class="close-detail-btn" onclick="closeBookDetail()">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/script.js"></script>
</body>
</html>