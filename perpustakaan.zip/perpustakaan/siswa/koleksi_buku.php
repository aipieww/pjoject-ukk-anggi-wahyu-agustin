<?php
include '../login/config.php';
session_start();


if (!isset($_SESSION['user']) || $_SESSION['user'] != 'siswa') {
    header('Location: ../login/index.php');
    exit;
}

$search = '';
if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
}

$id_anggota = $_SESSION['id_anggota'];
$nama = $_SESSION['nama'];


if (isset($_GET['pinjam'])) {
    $id_buku = $_GET['pinjam'];

   
    $query_stok = "SELECT stok FROM buku WHERE id_buku = $id_buku";
    $result_stok = mysqli_query($conn, $query_stok);
    if ($result_stok && mysqli_num_rows($result_stok) > 0) {
        $row_stok = mysqli_fetch_assoc($result_stok);

        if ($row_stok['stok'] > 0) {
            
            $query_update_stok = "UPDATE buku SET stok = stok - 1 WHERE id_buku = $id_buku";
            mysqli_query($conn, $query_update_stok);

            
            $tanggal_pinjam = date('Y-m-d');
            $batas_kembali = date('Y-m-d', strtotime('+7 days'));

            $query_pinjam = "INSERT INTO peminjaman (id_anggota, id_buku, tanggal_pinjam, batas_kembali, status) VALUES ($id_anggota, $id_buku, '$tanggal_pinjam', '$batas_kembali', 'dipinjam')";
            mysqli_query($conn, $query_pinjam);

            echo "<script>alert('Buku berhasil dipinjam!'); window.location='koleksi_buku.php';</script>";
        } else {
            echo "<script>alert('Stok buku habis!'); window.location='koleksi_buku.php';</script>";
        }
    } else {
        echo "<script>alert('Buku tidak ditemukan!'); window.location='koleksi_buku.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Koleksi Buku</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
 
    <div class="sidebar">
        <h2>Lumina Archive</h2>
        <a href="dashboard.php?page=home">Home</a>
        <a href="koleksi_buku.php">Koleksi Buku</a>
        <a href="laporan.php">Laporan</a>
        <a href="../login/logout.php">Logout</a>
    </div>

    <div class="content">
        <header class="topbar">
<span>
                   <h1>Koleksi Buku</h1>
                </span>
                
                 <search>
            <input id="searchInput" type="text" placeholder="Cari buku..." oninput="searchBooks()">
            
        </search>
        

        </header>
        
        <div class="cards">
            <?php
            $search_clause = '';
            if ($search !== '') {
                $search_term = mysqli_real_escape_string($conn, $search);
                $search_clause = "AND (judul_buku LIKE '%$search_term%' OR pengarang LIKE '%$search_term%' OR penerbit LIKE '%$search_term%')";
            }
            $query_buku = "SELECT * FROM buku WHERE stok > 0 $search_clause ORDER BY judul_buku ASC";
            $result_buku = mysqli_query($conn, $query_buku);

            if ($result_buku && mysqli_num_rows($result_buku) > 0) {
                while ($row = mysqli_fetch_assoc($result_buku)) {
                    $cover_path = $row['cover'] ? '../assets/cover/' . $row['cover'] : 'https://via.placeholder.com/180x150?text=No+Cover';
                    $bukuData = json_encode([
                        'judul' => $row['judul_buku'],
                        'pengarang' => $row['pengarang'],
                        'penerbit' => $row['penerbit'],
                        'tahun' => $row['tahun_terbit'],
                        'stok' => $row['stok'],
                        'sinopsis' => $row['sinopsis'] ?? '',
                        'cover' => $cover_path,
                        'id' => $row['id_buku']
                    ]);
            ?>
            <div class="card" onclick="openBookDetail(this)" data-book='<?php echo htmlspecialchars($bukuData, ENT_QUOTES, 'UTF-8'); ?>' style="cursor: pointer;">
                <img src="<?php echo $cover_path; ?>" alt="<?php echo $row['judul_buku']; ?>">
                <h4><?php echo substr($row['judul_buku'], 0, 18); ?></h4>
                <p><strong><?php echo $row['pengarang']; ?></strong></p>
                <p>Stok: <span style="color: #f18282; font-weight: bold;"><?php echo $row['stok']; ?></span></p>
                <a href="koleksi_buku.php?pinjam=<?php echo $row['id_buku']; ?>" class="btn-pinjam" onclick="return confirm('Yakin ingin meminjam buku ini?')">Pinjam</a>
            </div>

            
            <?php
                }
            } else {
                echo "<p style='color: #999;'>Belum ada buku tersedia</p>";
            }
            ?>
        </div>
    </div>

    <!-- Book Detail Modal -->
    <div id="bookDetailModal">
        <div class="book-detail-container">
            <div class="book-detail-cover">
                <img id="bookCover" src="" alt="Book Cover">
            </div>
            <div class="book-detail-info">
                <h2 id="bookTitle">-</h2>
                <div class="detail-item">
                    <div class="detail-label">Pengarang</div>
                    <div class="detail-value" id="bookAuthor">-</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Penerbit</div>
                    <div class="detail-value" id="bookPublisher">-</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Tahun Terbit</div>
                    <div class="detail-value" id="bookYear">-</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Stok Tersedia</div>
                    <div class="detail-value" id="bookStock">-</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Deskripsi</div>
                    <div class="book-detail-synopsis" id="bookSynopsis">-</div>
                </div>
                <div class="book-detail-actions">
                    <button class="close-detail-btn" onclick="closeBookDetail()">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <script src="../assets/js/script.js"></script>

</body>
</html>