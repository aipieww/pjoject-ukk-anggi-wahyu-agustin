<?php
include '../login/config.php';
session_start();


if (!isset($_SESSION['user']) || $_SESSION['user'] != 'siswa') {
    header('Location: ../login/index.php');
    exit;
}

$id_anggota = $_SESSION['id_anggota'];
$nama = $_SESSION['nama'];


if (isset($_GET['kembali'])) {
    $id_peminjaman = $_GET['kembali'];

  
    $query_data = "SELECT id_buku FROM peminjaman WHERE id_peminjaman = $id_peminjaman AND id_anggota = $id_anggota";
    $result_data = mysqli_query($conn, $query_data);
    if ($result_data && mysqli_num_rows($result_data) > 0) {
        $row_data = mysqli_fetch_assoc($result_data);

        if ($row_data) {
            $id_buku = $row_data['id_buku'];

            
            $query_update = "UPDATE peminjaman SET status = 'dikembalikan' WHERE id_peminjaman = $id_peminjaman";
            mysqli_query($conn, $query_update);

           
            $query_stok = "UPDATE buku SET stok = stok + 1 WHERE id_buku = $id_buku";
            mysqli_query($conn, $query_stok);


            $tanggal_kembali = date('Y-m-d');
            $query_pengembalian = "INSERT INTO pengembalian (id_peminjaman, tanggal_kembali) VALUES ($id_peminjaman, '$tanggal_kembali')";
            mysqli_query($conn, $query_pengembalian);

            echo "<script>alert('Buku berhasil dikembalikan!'); window.location='laporan.php';</script>";
        }
    } else {
        echo "<script>alert('Data peminjaman tidak ditemukan!'); window.location='laporan.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan - Perpustakaan</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="sidebar">
        <h2>Lumina Archive</h2>

        <a href="dashboard.php?page=home">Home</a>
        <a href="koleksi_buku.php">Koleksi Buku</a>
        <a href="laporan.php">Laporan</a>
        <a href="../login/logout.php">Logout</a>
    </div>

    <div class="content">
        <h1>Laporan Peminjaman</h1>

        <h2>Buku Sedang Dipinjam</h2>
        <table>
            <tr>
                <th>Judul Buku</th>
                <th>Tanggal Pinjam</th>
                <th>Batas Kembali</th>
                <th>Aksi</th>
            </tr>
            <?php
            $query_pinjam = "SELECT p.*, b.judul_buku FROM peminjaman p JOIN buku b ON p.id_buku = b.id_buku WHERE p.id_anggota = $id_anggota AND p.status = 'dipinjam'";
            $result_pinjam = mysqli_query($conn, $query_pinjam);

            if ($result_pinjam && mysqli_num_rows($result_pinjam) > 0) {
                while ($row = mysqli_fetch_assoc($result_pinjam)) {
            ?>
            <tr>
                <td><?php echo $row['judul_buku']; ?></td>
                <td><?php echo $row['tanggal_pinjam']; ?></td>
                <td><?php echo $row['batas_kembali']; ?></td>
                <td>
                    <a href="laporan.php?kembali=<?php echo $row['id_peminjaman']; ?>" class="btn-kembali" onclick="return confirm('Yakin ingin mengembalikan buku ini?')">Kembali</a>
                </td>
            </tr>
            <?php
                }
            } else {
                echo "<tr><td colspan='4' style='text-align: center; color: #999;'>Belum ada buku yang dipinjam</td></tr>";
            }
            ?>
        </table>

        <h2>Riwayat Peminjaman</h2>
        <table>
            <tr>
                <th>Judul Buku</th>
                <th>Tanggal Pinjam</th>
                <th>Tanggal Kembali</th>
                <th>Status</th>
            </tr>
            <?php
            $query_riwayat = "SELECT p.*, b.judul_buku, pg.tanggal_kembali FROM peminjaman p JOIN buku b ON p.id_buku = b.id_buku LEFT JOIN pengembalian pg ON p.id_peminjaman = pg.id_peminjaman WHERE p.id_anggota = $id_anggota AND p.status = 'dikembalikan' ORDER BY p.tanggal_pinjam DESC";
            $result_riwayat = mysqli_query($conn, $query_riwayat);

            if ($result_riwayat && mysqli_num_rows($result_riwayat) > 0) {
                while ($row = mysqli_fetch_assoc($result_riwayat)) {
            ?>
            <tr>
                <td><?php echo $row['judul_buku']; ?></td>
                <td><?php echo $row['tanggal_pinjam']; ?></td>
                <td><?php echo $row['tanggal_kembali'] ?? '-'; ?></td>
                <td><span class="status-dikembalikan">Dikembalikan</span></td>
            </tr>
            <?php
                }
            } else {
                echo "<tr><td colspan='4' style='text-align: center; color: #999;'>Belum ada riwayat peminjaman</td></tr>";
            }
            ?>
        </table>
    </div>

    <script src="../assets/js/script.js"></script>
</body>
</html>