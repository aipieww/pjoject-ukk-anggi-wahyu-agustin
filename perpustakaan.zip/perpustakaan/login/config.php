<?php
$host = "localhost";
$siswaname = "root";
$password = "";
$db = "perpustakaan";

$conn = mysqli_connect($host, $siswaname, $password, $db);
if (!$conn) {
    die("Koneksi Gagal: " . mysqli_connect_error());
}
?>