<?php
include 'config.php';
session_start();


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {

    $type = $_POST['type'] ?? '';

    
    if ($type == 'admin') {

        if (isset($_POST['username']) && isset($_POST['password_admin'])) {

            $username = $_POST['username'];
            $password = $_POST['password_admin'];

            if ($username === 'admin' && $password === 'admin123!') {
                
                $check_user = "SELECT id_user FROM users WHERE username = 'admin' AND role = 'admin'";
                $result_check = mysqli_query($conn, $check_user);
                
                if (mysqli_num_rows($result_check) == 0) {
                  
                    $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                    $insert_user = "INSERT INTO users (username, password, role, status) VALUES ('admin', '$hashed_password', 'admin', 'aktif')";
                    mysqli_query($conn, $insert_user);
                }
                
                $_SESSION['user'] = 'admin';
                $_SESSION['username'] = $username;
                header('Location: ../admin/dashboard.php');
                exit;
            } else {
                $error = "Username atau password admin salah!";
            }

        } else {
            $error = "Form admin belum lengkap!";
        }

    
    } elseif ($type == 'siswa') {

        if (isset($_POST['nis']) && isset($_POST['password_siswa'])) {

            $nis = $_POST['nis'];
            $password = $_POST['password_siswa'];

            
            $check_user = "SELECT * FROM users WHERE username = '$nis' AND role = 'siswa'";
            $result_check = mysqli_query($conn, $check_user);

            if ($result_check && mysqli_num_rows($result_check) > 0) {
                $user_row = mysqli_fetch_assoc($result_check);


                if (password_verify($password, $user_row['password'])) {

                    // Cari anggota berdasarkan id_user, bukan NIS
                    $query_anggota = "SELECT id_anggota, nama_anggota, status_verifikasi FROM anggota WHERE id_user = " . $user_row['id_user'];
                    $result_anggota = mysqli_query($conn, $query_anggota);

                    if ($result_anggota && mysqli_num_rows($result_anggota) > 0) {
                        $anggota_row = mysqli_fetch_assoc($result_anggota);

                        // Cek status verifikasi
                        if ($anggota_row['status_verifikasi'] === 'terverifikasi') {
                            $_SESSION['user'] = 'siswa';
                            $_SESSION['id_anggota'] = $anggota_row['id_anggota'];
                            $_SESSION['nama'] = $anggota_row['nama_anggota'];
                            $_SESSION['nis'] = $nis;
                            header('Location: ../siswa/dashboard.php');
                            exit;
                        } elseif ($anggota_row['status_verifikasi'] === 'ditolak') {
                            $error = "Akun Anda telah ditolak oleh admin. Silakan hubungi administrator.";
                        } else {
                            $error = "Akun Anda masih menunggu verifikasi dari admin. Silakan tunggu.";
                        }
                    } else {
                        $error = "Data anggota tidak ditemukan di sistem!";
                    }
                } else {
                    $error = "Password siswa salah!";
                }
            } else {
                $error = "NIS tidak ditemukan! Silakan registrasi terlebih dahulu.";
            }

        } else {
            $error = "Form siswa belum lengkap!";
        }
    }
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {

    $nama = trim($_POST['nama']);
    $nis = trim($_POST['nis']);
    $kelas = trim($_POST['kelas']);
    $password = $_POST['password'];

    // Validasi input
    if (empty($nama) || empty($nis) || empty($kelas) || empty($password)) {
        $error = "Semua field harus diisi!";
    } elseif (strlen($nis) < 5) {
        $error = "NIS minimal 5 karakter!";
    } elseif (strlen($password) < 6) {
        $error = "Password minimal 6 karakter!";
    } else {

        // Cek apakah NIS sudah terdaftar di tabel users
        $check_nis_users = "SELECT id_user FROM users WHERE username = '$nis'";
        $result_check_nis_users = mysqli_query($conn, $check_nis_users);

        if (!$result_check_nis_users) {
            $error = "Error database: " . mysqli_error($conn);
        } elseif (mysqli_num_rows($result_check_nis_users) > 0) {
            $error = "NIS sudah terdaftar! Silakan gunakan NIS lain.";
        } else {

            // Cek apakah NIS sudah terdaftar di tabel anggota (untuk backward compatibility)
            $check_nis_anggota = "SELECT id_anggota FROM anggota WHERE nis = '$nis'";
            $result_check_nis_anggota = mysqli_query($conn, $check_nis_anggota);

            if (mysqli_num_rows($result_check_nis_anggota) > 0) {
                $error = "NIS sudah terdaftar di sistem! Silakan gunakan NIS lain.";
            } else {

                // Hash password
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);

                // Insert ke tabel users
                $insert_user = "INSERT INTO users (username, password, role, status) VALUES ('$nis', '$hashed_password', 'siswa', 'aktif')";

                if (mysqli_query($conn, $insert_user)) {
                    $user_id = mysqli_insert_id($conn);

                    // Insert ke tabel anggota dengan id_user yang baru dan status belum terverifikasi
                    $insert_anggota = "INSERT INTO anggota (id_user, nis, nama_anggota, kelas, status_verifikasi) VALUES ($user_id, '$nis', '$nama', '$kelas', 'belum_diverifikasi')";

                    if (mysqli_query($conn, $insert_anggota)) {
                        $anggota_id = mysqli_insert_id($conn);

                        // Tampilkan pesan sukses bahwa akun menunggu verifikasi
                        $success = "Registrasi berhasil! Akun Anda menunggu verifikasi dari admin. Anda akan dapat login setelah diverifikasi.";
                    } else {
                        $error = "Gagal membuat profil anggota! Error: " . mysqli_error($conn);
                        // Hapus user yang sudah dibuat jika gagal membuat anggota
                        mysqli_query($conn, "DELETE FROM users WHERE id_user = $user_id");
                    }
                } else {
                    $error = "Registrasi gagal! Error: " . mysqli_error($conn);
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="UTF-8">
        <title>Login Lumina Archive</title>
        <link rel="stylesheet" href="../assets/css/style.css">
    </head>

    <body>
        <div class="login-page">
            <div class="login-container">
                <div class="info-panel">
                    <span class="tag">Library digital</span>
                    <h2>LUMINA ARCHIVE</h2>
                    <p>Where knowledge shines and ideas come to life — welcome to Lumina Archive.</p>
                </div>

                <div class="login-panel">
                    <?php if (isset($error)) echo "<div class='error'>" . htmlspecialchars($error) . "</div>"; ?>
                    <?php if (isset($success)) echo "<div class='success'>" . htmlspecialchars($success) . "</div>"; ?>
                    <h1>Masuk ke Lumina Archive</h1>
                    <p>Kelola koleksi, akses pinjaman, dan temukan buku favorit dengan antarmuka yang modern dan nyaman.</p>

                    <div class="login-toggle">
                        <button type="button" class="toggle-btn active" data-target="admin-fields">Admin</button>
                        <button type="button" class="toggle-btn" data-target="siswa-fields">Siswa</button>
                    </div>

                    <form method="POST" class="form-row">

                        <input type="hidden" name="type" id="type" value="admin">
                        <div class="field-group" id="admin-fields">
                            <label for="username">Username Admin</label>
                            <input type="text" name="username" id="username" placeholder="admin" autocomplete="username">
                            <label for="password_admin">Password Admin</label>
                            <input type="password" name="password_admin" id="password_admin" placeholder="••••••••" autocomplete="current-password">
                        </div>

                        <div class="field-group" id="siswa-fields" style="display:none;">
                            <label for="nis">NIS</label>
                            <input type="text" name="nis" id="nis" placeholder="Masukkan NIS" autocomplete="username">
                            <label for="password_siswa">Password Siswa</label>
                            <input type="password" name="password_siswa" id="password_siswa" placeholder="••••••••" autocomplete="current-password">
                        </div>

                        <div class="submit-group">
                            <button type="submit" name="login">Login</button>
                            <button type="button" class="btn-search" onclick="showRegister(event)">Registrasi Siswa</button>
                        </div>
                    </form>

                    <div id="register-form" style="display:none; margin-top: 24px;">
                        <h2>Registrasi Siswa</h2>
                        <form method="POST" class="form-row">
                            <div class="field-group">
                                <label for="nama">Nama Lengkap</label>
                                <input type="text" name="nama" id="nama" placeholder="Nama Lengkap" required>
                            </div>
                            <div class="field-group">
                                <label for="nis_reg">NIS</label>
                                <input type="text" name="nis" id="nis_reg" placeholder="NIS" required>
                            </div>
                            <div class="field-group">
                                <label for="kelas">Kelas</label>
                                <input type="text" name="kelas" id="kelas" placeholder="Kelas" required>
                            </div>
                            <div class="field-group">
                                <label for="password">Password</label>
                                <input type="password" name="password" id="password" placeholder="Password" required>
                            </div>
                            <button type="submit" name="register">Daftar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

<script>
    const typeInput = document.getElementById('type');
    const adminFields = document.getElementById('admin-fields');
    const siswaFields = document.getElementById('siswa-fields');
    const toggleButtons = document.querySelectorAll('.toggle-btn');

    toggleButtons.forEach(button => {
        button.addEventListener('click', () => {
            toggleButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            const target = button.getAttribute('data-target');
            if (target === 'admin-fields') {
                adminFields.style.display = 'block';
                siswaFields.style.display = 'none';
                typeInput.value = 'admin';
            } else {
                adminFields.style.display = 'none';
                siswaFields.style.display = 'block';
                typeInput.value = 'siswa';
            }
        });
    });

    function showRegister(event) {
        event.preventDefault();
        document.getElementById('register-form').style.display = 'block';
    }
</script>

</body>
</html>