<?php
include '../login/config.php';
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user'] != 'admin') {
    header('Location: ../login/index.php');
    exit;
}

$search = '';
if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
}

// Fungsi verifikasi akun
if (isset($_GET['verifikasi_akun'])) {
    $id_anggota = (int)$_GET['verifikasi_akun'];
    
    if ($id_anggota > 0) {
        $query = "UPDATE anggota SET status_verifikasi = 'terverifikasi' WHERE id_anggota = $id_anggota";
        if (mysqli_query($conn, $query)) {
            $success = "Akun anggota berhasil diverifikasi!";
        } else {
            $error = "Gagal memverifikasi akun: " . mysqli_error($conn);
        }
    }
}

// Fungsi tolak verifikasi
if (isset($_GET['tolak_verifikasi'])) {
    $id_anggota = (int)$_GET['tolak_verifikasi'];
    
    if ($id_anggota > 0) {
        $query = "UPDATE anggota SET status_verifikasi = 'ditolak' WHERE id_anggota = $id_anggota";
        if (mysqli_query($conn, $query)) {
            $success = "Akun anggota berhasil ditolak!";
        } else {
            $error = "Gagal menolak akun: " . mysqli_error($conn);
        }
    }
}

// Fungsi reset verifikasi (kembali ke belum_diverifikasi)
if (isset($_GET['reset_verifikasi'])) {
    $id_anggota = (int)$_GET['reset_verifikasi'];
    
    if ($id_anggota > 0) {
        $query = "UPDATE anggota SET status_verifikasi = 'belum_diverifikasi' WHERE id_anggota = $id_anggota";
        if (mysqli_query($conn, $query)) {
            $success = "Status verifikasi akun berhasil direset!";
        } else {
            $error = "Gagal mereset status verifikasi: " . mysqli_error($conn);
        }
    }
}

if (isset($_GET['hapus_anggota'])) {
    $id_anggota = (int)$_GET['hapus_anggota'];

    if ($id_anggota <= 0) {
        $error = "ID anggota tidak valid!";
    } else {
        // Mulai transaction untuk safety
        mysqli_begin_transaction($conn);

        try {
            // 1. Cek apakah anggota ada dan dapatkan id_siswa
            $query_check = "SELECT id_siswa FROM anggota WHERE id_anggota = ?";
            $stmt_check = mysqli_prepare($conn, $query_check);
            mysqli_stmt_bind_param($stmt_check, "i", $id_anggota);
            mysqli_stmt_execute($stmt_check);
            $result_check = mysqli_stmt_get_result($stmt_check);

            if (!$result_check || mysqli_num_rows($result_check) == 0) {
                throw new Exception("Anggota tidak ditemukan!");
            }

            $row_check = mysqli_fetch_assoc($result_check);
            $id_siswa = $row_check['id_siswa'];
            mysqli_stmt_close($stmt_check);

            // 2. Hapus data pengembalian yang terkait (gunakan prepared statement)
            $query_pengembalian = "DELETE FROM pengembalian WHERE id_peminjaman IN (SELECT id_peminjaman FROM peminjaman WHERE id_anggota = ?)";
            $stmt_pengembalian = mysqli_prepare($conn, $query_pengembalian);
            mysqli_stmt_bind_param($stmt_pengembalian, "i", $id_anggota);
            if (!mysqli_stmt_execute($stmt_pengembalian)) {
                throw new Exception("Gagal menghapus data pengembalian: " . mysqli_error($conn));
            }
            mysqli_stmt_close($stmt_pengembalian);

            // 3. Hapus data peminjaman yang terkait (gunakan prepared statement)
            $query_peminjaman = "DELETE FROM peminjaman WHERE id_anggota = ?";
            $stmt_peminjaman = mysqli_prepare($conn, $query_peminjaman);
            mysqli_stmt_bind_param($stmt_peminjaman, "i", $id_anggota);
            if (!mysqli_stmt_execute($stmt_peminjaman)) {
                throw new Exception("Gagal menghapus data peminjaman: " . mysqli_error($conn));
            }
            mysqli_stmt_close($stmt_peminjaman);

            // 4. Hapus data anggota (gunakan prepared statement)
            $query_anggota = "DELETE FROM anggota WHERE id_anggota = ?";
            $stmt_anggota = mysqli_prepare($conn, $query_anggota);
            mysqli_stmt_bind_param($stmt_anggota, "i", $id_anggota);
            if (!mysqli_stmt_execute($stmt_anggota)) {
                throw new Exception("Gagal menghapus anggota: " . mysqli_error($conn));
            }
            mysqli_stmt_close($stmt_anggota);

            // 5. Hapus data siswa jika ada (gunakan prepared statement)
            if ($id_siswa) {
                $query_siswa = "DELETE FROM siswas WHERE id_siswa = ?";
                $stmt_siswa = mysqli_prepare($conn, $query_siswa);
                mysqli_stmt_bind_param($stmt_siswa, "i", $id_siswa);
                if (!mysqli_stmt_execute($stmt_siswa)) {
                    throw new Exception("Gagal menghapus siswa: " . mysqli_error($conn));
                }
                mysqli_stmt_close($stmt_siswa);
            }

            // Commit transaction
            mysqli_commit($conn);
            $success = "Anggota dan data terkait berhasil dihapus!";

        } catch (Exception $e) {
            // Rollback jika ada error
            mysqli_rollback($conn);
            $error = $e->getMessage();
        }
    }
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_anggota'])) {
    $id = $_POST['id_anggota'];
    $nis = $_POST['nis'];
    $nama = $_POST['nama_anggota'];
    $kelas = $_POST['kelas'];
    
    
    $query = "UPDATE anggota SET id_anggota=$id, nis='$nis', nama_anggota='$nama', kelas='$kelas' WHERE id_anggota=$id";
    
    if (mysqli_query($conn, $query)) {
        $success = "Anggota berhasil diupdate!";
    } else {
        $error = "Gagal mengupdate anggota: " . mysqli_error($conn);
    }
}

// Fungsi untuk mendapatkan status badge
function getStatusBadge($status) {
    switch ($status) {
        case 'terverifikasi':
            return '<span style="background: #28a745; color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px;">✓ Terverifikasi</span>';
        case 'ditolak':
            return '<span style="background: #dc3545; color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px;">✗ Ditolak</span>';
        default:
            return '<span style="background: #ffc107; color: black; padding: 4px 8px; border-radius: 4px; font-size: 12px;">⏳ Menunggu</span>';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Anggota</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="sidebar">
        <h2>Lumina Archive</h2>
        <a href="dashboard.php">Home</a>
        <a href="kelola_buku.php">Kelola Buku</a>
        <a href="kelola_anggota.php" class="active">Kelola Anggota</a>
        <a href="laporan.php">Laporan</a>
        <a href="../login/logout.php">Logout</a>
    </div>

    <div class="content">

    <header class="topbar">
        <span>
            <h1>Kelola Anggota</h1>
        </span>

        <search>
            <form method="GET" style="display:flex; align-items:center; gap:8px;">
                <input type="text" name="search" placeholder="Cari anggota..." value="<?php echo htmlspecialchars($search); ?>" style="padding: 8px; width: 260px;">
                <button type="submit" class="btn btn-search">Cari</button>
                <?php if ($search !== ''): ?>
                    <a href="kelola_anggota.php" class="btn btn-reset" style="padding: 8px 12px; text-decoration:none; background:#6c757d; color:#fff; border-radius:4px;">Reset</a>
                <?php endif; ?>
            </form>
        </search>
    </header>
        <?php if (isset($success)) echo "<div class='success'>$success</div>"; ?>
        <?php if (isset($error)) echo "<div class='error'>$error</div>"; ?>

        <h1>Kelola Anggota</h1>
        
        <table>
            <tr>
                <th>No</th>
                <th>NIS</th>
                <th>Nama</th>
                <th>Kelas</th>
                <th>Status Verifikasi</th>
                <th>Aksi</th>
            </tr>
            <?php
            $search_clause = '';
            if ($search !== '') {
                $search_term = mysqli_real_escape_string($conn, $search);
                $search_clause = "WHERE nis LIKE '%$search_term%' OR nama_anggota LIKE '%$search_term%' OR kelas LIKE '%$search_term%'";
            }
            $result = mysqli_query($conn, "SELECT * FROM anggota $search_clause ORDER BY nama_anggota ASC");
            if ($result && mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <tr>
                <td><?php echo $row['id_anggota']; ?></td>
                <td><?php echo $row['nis']; ?></td>
                <td><?php echo $row['nama_anggota']; ?></td>
                <td><?php echo $row['kelas']; ?></td>
                <td><?php echo getStatusBadge($row['status_verifikasi'] ?? 'belum_diverifikasi'); ?></td>
                <td>
                    <button class="btn btn-edit" onclick="editAnggota(<?php echo htmlspecialchars(json_encode($row)); ?>)">Edit</button>
                    <?php if (($row['status_verifikasi'] ?? 'belum_diverifikasi') === 'belum_diverifikasi'): ?>
                        <a href="kelola_anggota.php?verifikasi_akun=<?php echo $row['id_anggota']; ?>" class="btn" style="background: #28a745; color: white; padding: 6px 12px; border-radius: 4px; text-decoration: none; font-size: 12px;" onclick="return confirm('Verifikasi akun ini?')">Verifikasi</a>
                        <a href="kelola_anggota.php?tolak_verifikasi=<?php echo $row['id_anggota']; ?>" class="btn" style="background: #dc3545; color: white; padding: 6px 12px; border-radius: 4px; text-decoration: none; font-size: 12px;" onclick="return confirm('Tolak akun ini?')">Tolak</a>
                    <?php else: ?>
                        <a href="kelola_anggota.php?reset_verifikasi=<?php echo $row['id_anggota']; ?>" class="btn" style="background: #6c757d; color: white; padding: 6px 12px; border-radius: 4px; text-decoration: none; font-size: 12px;" onclick="return confirm('Reset status verifikasi?')">Reset</a>
                    <?php endif; ?>
                    <a href="kelola_anggota.php?hapus_anggota=<?php echo $row['id_anggota']; ?>" class="btn btn-delete" onclick="return confirm('Yakin hapus anggota ini?')">Hapus</a>
                </td>
            </tr>
            <?php
                }
            } else {
                echo "<tr><td colspan='6' style='text-align: center; color: #999;'>Belum ada data anggota</td></tr>";
            }
            ?>
        </table>
    </div>

    <div id="edit-anggota" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Edit Anggota</h2>
                <span class="close-btn" onclick="closeModal('edit-anggota')">&times;</span>
            </div>
            <form method="POST">
                <input type="hidden" id="edit_id_anggota" name="id_anggota">
                <div class="form-group">
                    <label>NIS</label>
                    <input type="text" id="edit_nis" name="nis" required>
                </div>
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" id="edit_nama_anggota" name="nama_anggota" required>
                </div>
                <div class="form-group">
                    <label>Kelas</label>
                    <input type="text" id="edit_kelas" name="kelas" required>
                </div>
                
                <button type="submit" name="edit_anggota" class="btn btn-tambah" style="background: #007bff; color: white; padding: 10px 20px; font-size: 14px;">Update</button>
            </form>
        </div>
    </div>

    <script>
        function showModal(id) {
            document.getElementById(id).classList.add('show');
        }
        function closeModal(id) {
            document.getElementById(id).classList.remove('show');
        }
        function editAnggota(data) {
            document.getElementById('edit_id_anggota').value = data.id_anggota;
            document.getElementById('edit_nis').value = data.nis;
            document.getElementById('edit_nama_anggota').value = data.nama_anggota;
            document.getElementById('edit_kelas').value = data.kelas;

            showModal('edit-anggota');
        }
        window.onclick = function(e) {
            if (e.target.classList.contains('modal')) {
                e.target.classList.remove('show');
            }
        }
    </script>

    <script src="../assets/js/script.js"></script>
</body>
</html>
