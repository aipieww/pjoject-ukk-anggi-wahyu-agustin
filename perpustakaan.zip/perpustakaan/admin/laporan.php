<?php
include '../login/config.php';
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user'] != 'admin') {
    header('Location: ../login/index.php');
    exit;
}

// Handle filter parameters

$filter_type = isset($_GET['filter_type']) ? $_GET['filter_type'] : '';
$filter_value = isset($_GET['filter_value']) ? mysqli_real_escape_string($conn, $_GET['filter_value']) : '';
$filter_date = isset($_GET['filter_date']) ? $_GET['filter_date'] : '';

if (isset($_GET['berhentikan'])) {
    $id_peminjaman = $_GET['berhentikan'];
    $query_data = "SELECT id_buku FROM peminjaman WHERE id_peminjaman = $id_peminjaman";
    $result_data = mysqli_query($conn, $query_data);
    if ($result_data && mysqli_num_rows($result_data) > 0) {
        $row_data = mysqli_fetch_assoc($result_data);
        if ($row_data) {
            $id_buku = $row_data['id_buku'];
            $query_update = "UPDATE peminjaman SET status = 'dikembalikan' WHERE id_peminjaman = $id_peminjaman";
            mysqli_query($conn, $query_update);
            $query_stok = "UPDATE buku SET stok = stok + 1 WHERE id_buku = $id_buku";
            mysqli_query($conn, $query_stok);
            $tanggal_kembali = date('Y-m-d');
            $query_pengembalian = "INSERT INTO pengembalian (id_peminjaman, tanggal_kembali) VALUES ($id_peminjaman, '$tanggal_kembali')";
            mysqli_query($conn, $query_pengembalian);
            // Redirect with new compact filter preserved
            $redirect_url = 'laporan.php';
            $params = [];
            if ($filter_type) $params[] = 'filter_type=' . urlencode($filter_type);
            if ($filter_value) $params[] = 'filter_value=' . urlencode($filter_value);
            if ($filter_date) $params[] = 'filter_date=' . urlencode($filter_date);
            if (!empty($params)) $redirect_url .= '?' . implode('&', $params);
            echo "<script>alert('Peminjaman berhasil dihentikan!'); window.location='$redirect_url';</script>";
        }
    } else {
        echo "<script>alert('Data peminjaman tidak ditemukan!'); window.location='laporan.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .search-form {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            align-items: center;
            margin-bottom: 20px;
            padding: 15px;
            background: #f9f9f9;
            border-radius: 4px;
        }
        .search-form input,
        .search-form select {
            padding: 8px 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        .search-form button {
            padding: 8px 16px;
            background: #445db1;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        .search-form button:hover {
            background: #2d3d6e;
        }
        .search-form a {
            padding: 8px 16px;
            background: #6c757d;
            color: white;
            border-radius: 4px;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
        }
        .search-form a:hover {
            background: #5a6268;
        }
        .filter-info {
            font-size: 12px;
            color: #666;
            margin-top: 10px;
        }
        @media print {
            .sidebar, header, .btn-berhentikan, .search-form, .filter-info {
                display: none !important;
            }
            .content {
                margin-left: 0 !important;
                width: 100% !important;
            }
            table {
                width: 100%;
                border-collapse: collapse;
            }
            th, td {
                border: 1px solid #ddd;
                padding: 8px;
                text-align: left;
            }
            th {
                background-color: #f2f2f2;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Lumina Archive</h2>
        <a href="dashboard.php">Home</a>
        <a href="kelola_buku.php">Kelola Buku</a>
        <a href="kelola_anggota.php">Kelola Anggota</a>
        <a href="laporan.php" class="active">Laporan</a>
        <a href="../login/logout.php">Logout</a>
    </div>



    

    <div class="content">
        <header>
            <span>
                <h1 style="display:inline-block;">Laporan Peminjaman & Pengembalian</h1>
            </span>
            <div style="display: flex; align-items: center; gap: 10px; flex: 1; justify-content: flex-end;">
                <form method="GET" action="laporan.php" id="mini-search-form" style="display: flex; align-items: center; gap: 6px;">
                    <select name="filter_type" id="filter_type" style="padding: 4px 8px; border-radius: 4px; border: 1px solid #ccc; font-size: 13px;">
                        <option value="nama" <?php if(isset($_GET['filter_type']) && $_GET['filter_type']==='nama') echo 'selected'; ?>>Nama</option>
                        <option value="buku" <?php if(isset($_GET['filter_type']) && $_GET['filter_type']==='buku') echo 'selected'; ?>>Buku</option>
                        <option value="tanggal" <?php if(isset($_GET['filter_type']) && $_GET['filter_type']==='tanggal') echo 'selected'; ?>>Tanggal</option>
                    </select>
                    <input type="text" name="filter_value" id="filter_value" placeholder="Cari..." value="<?php echo isset($_GET['filter_value']) ? htmlspecialchars($_GET['filter_value']) : ''; ?>" style="padding: 4px 10px; border-radius: 4px; border: 1px solid #ccc; font-size: 13px; width: 120px;">
                    <input type="date" name="filter_date" id="filter_date" value="<?php echo isset($_GET['filter_date']) ? htmlspecialchars($_GET['filter_date']) : ''; ?>" style="display:none; padding: 4px 10px; border-radius: 4px; border: 1px solid #ccc; font-size: 13px; width: 120px;">
                    <button type="submit" style="padding: 4px 14px; font-size: 13px; border-radius: 4px; background: #445db1; color: white; border: none; cursor: pointer;">Cari</button>
                    <a href="laporan.php" style="padding: 4px 14px; font-size: 13px; border-radius: 4px; background: #6c757d; color: white; text-decoration: none;">Reset</a>
                </form>
                <button onclick="printAll()" style="background: #445db1; color: white; border: none; padding: 2px 6px; border-radius: 8px; cursor: pointer;">Print Semua</button>
                <button onclick="printPeminjaman()" style="background: #445db1; color: white; border: none; padding: 2px 6px; border-radius: 8px; cursor: pointer;">Print Peminjaman</button>
                <button onclick="printPengembalian()" style="background: #445db1; color: white; border: none; padding: 2px 6px; border-radius: 8px; cursor: pointer;">Print Pengembalian</button>
            </div>
        </header>

        <script>
        // Mini search bar logic: switch input type
        const filterType = document.getElementById('filter_type');
        const filterValue = document.getElementById('filter_value');
        const filterDate = document.getElementById('filter_date');
        function updateSearchInput() {
            if (filterType.value === 'tanggal') {
                filterValue.style.display = 'none';
                filterDate.style.display = 'inline-block';
            } else {
                filterValue.style.display = 'inline-block';
                filterDate.style.display = 'none';
                filterValue.placeholder = filterType.value === 'nama' ? 'Cari Nama...' : 'Cari Buku...';
            }
        }
        filterType && filterType.addEventListener('change', updateSearchInput);
        window.addEventListener('DOMContentLoaded', updateSearchInput);
        </script>

        <?php
        // Show filter info bar if filter is active
        $filter_info = '';
        if (isset($_GET['filter_type'])) {
            if ($_GET['filter_type'] === 'nama' && !empty($_GET['filter_value'])) {
                $filter_info = 'Filter: Nama = <strong>' . htmlspecialchars($_GET['filter_value']) . '</strong>';
            } elseif ($_GET['filter_type'] === 'buku' && !empty($_GET['filter_value'])) {
                $filter_info = 'Filter: Buku = <strong>' . htmlspecialchars($_GET['filter_value']) . '</strong>';
            } elseif ($_GET['filter_type'] === 'tanggal' && !empty($_GET['filter_date'])) {
                $filter_info = 'Filter: Tanggal = <strong>' . htmlspecialchars($_GET['filter_date']) . '</strong>';
            }
        }
        if ($filter_info) {
            echo '<div class="filter-info" style="margin-bottom:10px; color:#666; font-size:13px;">' . $filter_info . '</div>';
        }
        ?>

        <!-- Data Peminjaman (Buku yang sedang dipinjam) -->
        <div id="section-peminjaman">
            <h2>Data Peminjaman (Buku yang Sedang Dipinjam)</h2>
            <table>
                <tr>
                    <th>No</th>
                    <th>Nama Siswa</th>
                    <th>Judul Buku</th>
                    <th>Tanggal Pinjam</th>
                    <th>Batas Kembali</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
                <?php
                $query_peminjaman = "

                    SELECT p.id_peminjaman, a.nama_anggota, b.judul_buku, p.tanggal_pinjam, p.batas_kembali, p.status
                    FROM peminjaman p
                    JOIN anggota a ON p.id_anggota = a.id_anggota
                    JOIN buku b ON p.id_buku = b.id_buku
                    WHERE p.status = 'dipinjam'
                ";
                // Add new compact filter
                if ($filter_type === 'nama' && $filter_value) {
                    $query_peminjaman .= " AND a.nama_anggota LIKE '%$filter_value%'";
                } elseif ($filter_type === 'buku' && $filter_value) {
                    $query_peminjaman .= " AND b.judul_buku LIKE '%$filter_value%'";
                } elseif ($filter_type === 'tanggal' && $filter_date) {
                    $query_peminjaman .= " AND p.tanggal_pinjam = '$filter_date'";
                }
                $query_peminjaman .= " ORDER BY p.tanggal_pinjam DESC";

                $result_peminjaman = mysqli_query($conn, $query_peminjaman);

                if ($result_peminjaman && mysqli_num_rows($result_peminjaman) > 0) {
                    while ($row = mysqli_fetch_assoc($result_peminjaman)) {
                ?>
                <tr>
                    <td><?php echo $row['id_peminjaman']; ?></td>
                    <td><?php echo $row['nama_anggota']; ?></td>
                    <td><?php echo $row['judul_buku']; ?></td>
                    <td><?php echo $row['tanggal_pinjam']; ?></td>
                    <td><?php echo $row['batas_kembali']; ?></td>
                    <td>
                        <span style="background: #ffc107; color: black; padding: 3px 8px; border-radius: 3px;">
                            <?php echo $row['status']; ?>
                        </span>
                    </td>
                    <td>
                        <a href="laporan.php?berhentikan=<?php echo $row['id_peminjaman']; ?><?php 
                            $filters = '';
                            if ($filter_type) $filters .= '&filter_type=' . urlencode($filter_type);
                            if ($filter_value) $filters .= '&filter_value=' . urlencode($filter_value);
                            if ($filter_date) $filters .= '&filter_date=' . urlencode($filter_date);
                            echo $filters;
                        ?>" class="btn-berhentikan"
                           onclick="return confirm('Yakin ingin berhentikan peminjaman ini?')">Berhentikan</a>
                    </td>
                </tr>
                <?php
                    }
                } else {
                    echo "<tr><td colspan='7' style='text-align: center; color: #999;'>Belum ada data peminjaman aktif</td></tr>";
                }
                ?>
            </table>
        </div>

        <br><br>

        <!-- Data Pengembalian (Buku yang sudah dikembalikan) -->
        <div id="section-pengembalian">
            <h2>Data Pengembalian (Buku yang Sudah Dikembalikan)</h2>
            <table>
                <tr>
                    <th>No</th>
                    <th>Nama Siswa</th>
                    <th>Judul Buku</th>
                    <th>Tanggal Pinjam</th>
                    <th>Tanggal Kembali</th>
                    <th>Status</th>
                </tr>
                <?php
                $query_pengembalian = "

                    SELECT p.id_peminjaman, a.nama_anggota, b.judul_buku, p.tanggal_pinjam, pg.tanggal_kembali, p.status
                    FROM peminjaman p
                    JOIN anggota a ON p.id_anggota = a.id_anggota
                    JOIN buku b ON p.id_buku = b.id_buku
                    JOIN pengembalian pg ON p.id_peminjaman = pg.id_peminjaman
                    WHERE p.status = 'dikembalikan'
                ";
                // Add new compact filter
                if ($filter_type === 'nama' && $filter_value) {
                    $query_pengembalian .= " AND a.nama_anggota LIKE '%$filter_value%'";
                } elseif ($filter_type === 'buku' && $filter_value) {
                    $query_pengembalian .= " AND b.judul_buku LIKE '%$filter_value%'";
                } elseif ($filter_type === 'tanggal' && $filter_date) {
                    $query_pengembalian .= " AND p.tanggal_pinjam = '$filter_date'";
                }
                $query_pengembalian .= " ORDER BY pg.tanggal_kembali DESC";

                $result_pengembalian = mysqli_query($conn, $query_pengembalian);

                if ($result_pengembalian && mysqli_num_rows($result_pengembalian) > 0) {
                    while ($row = mysqli_fetch_assoc($result_pengembalian)) {
                ?>
                <tr>
                    <td><?php echo $row['id_peminjaman']; ?></td>
                    <td><?php echo $row['nama_anggota']; ?></td>
                    <td><?php echo $row['judul_buku']; ?></td>
                    <td><?php echo $row['tanggal_pinjam']; ?></td>
                    <td><?php echo $row['tanggal_kembali']; ?></td>
                    <td>
                        <span style="background: #28a745; color: white; padding: 3px 8px; border-radius: 3px;">
                            <?php echo $row['status']; ?>
                        </span>
                    </td>
                </tr>
                <?php
                    }
                } else {
                    echo "<tr><td colspan='6' style='text-align: center; color: #999;'>Belum ada data pengembalian</td></tr>";
                }
                ?>
            </table>
        </div>
    </div>

    <script>
        function printAll() {
            // Print semua laporan (peminjaman + pengembalian)
            window.print();
        }

        function printPeminjaman() {
            // Sembunyikan section pengembalian, print hanya peminjaman
            document.getElementById('section-pengembalian').style.display = 'none';
            document.querySelector('h1').textContent = 'Laporan Peminjaman';
            window.print();
            // Kembalikan tampilan setelah print
            setTimeout(function() {
                document.getElementById('section-pengembalian').style.display = 'block';
                document.querySelector('h1').textContent = 'Laporan Peminjaman & Pengembalian';
            }, 1000);
        }

        function printPengembalian() {
            // Sembunyikan section peminjaman, print hanya pengembalian
            document.getElementById('section-peminjaman').style.display = 'none';
            document.querySelector('h1').textContent = 'Laporan Pengembalian';
            window.print();
            // Kembalikan tampilan setelah print
            setTimeout(function() {
                document.getElementById('section-peminjaman').style.display = 'block';
                document.querySelector('h1').textContent = 'Laporan Peminjaman & Pengembalian';
            }, 1000);
        }
    </script>
</body>
</html>
