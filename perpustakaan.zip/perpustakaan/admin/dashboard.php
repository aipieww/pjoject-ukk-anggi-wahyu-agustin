    <?php
    include '../login/config.php';
    session_start();


    if (!isset($_SESSION['user']) || $_SESSION['user'] != 'admin') {
        header('Location: ../login/index.php');
        exit;
    }


    $total_buku = 0;
    $total_anggota = 0;
    $total_stok = 0;

    $query_buku = "SELECT COUNT(*) as total_buku FROM buku";
    $result_buku = mysqli_query($conn, $query_buku);
    if ($result_buku) {
        $row_buku = mysqli_fetch_assoc($result_buku);
        $total_buku = $row_buku['total_buku'];
    }

    $query_anggota = "SELECT COUNT(*) as total_anggota FROM anggota";
    $result_anggota = mysqli_query($conn, $query_anggota);
    if ($result_anggota) {
        $row_anggota = mysqli_fetch_assoc($result_anggota);
        $total_anggota = $row_anggota['total_anggota'];
    }

    $query_stok = "SELECT SUM(stok) as total_stok FROM buku";
    $result_stok = mysqli_query($conn, $query_stok);
    if ($result_stok) {
        $row_stok = mysqli_fetch_assoc($result_stok);
        $total_stok = $row_stok['total_stok'] ?? 0;
    }
    ?>

    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <title>Dashboard</title>
        <link rel="stylesheet" href="../assets/css/style.css">
    </head>
    <body>
 
        <div class="sidebar">
            <h2>Lumina Archive</h2>
            <a href="dashboard.php" class="active">Home</a>
            <a href="kelola_buku.php">Kelola Buku</a>
            <a href="kelola_anggota.php">Kelola Anggota</a>
            <a href="laporan.php">Laporan</a>
            <a href="../login/logout.php">Logout</a>
        </div>

        <div class="content">
            <header class="topbar">
                <span>
                   <h1>Dashboard Admin</h1>
                </span>
                
                 <search>
            <input id="searchInput" type="text" placeholder="Cari buku..." oninput="searchBooks()">
            
        </search>
                    
                    
            </header>
            
            <div class="stats">
                <div class="stat">
                    <h3>Jumlah Buku</h3>
                    <p><?php echo $total_buku; ?></p>
                </div>
                <div class="stat">
                    <h3>Jumlah Anggota</h3>
                    <p><?php echo $total_anggota; ?></p>
                </div>
                <div class="stat">
                    <h3>Total Stok Buku</h3>
                    <p><?php echo $total_stok; ?></p>
                </div>
            </div>

            <h2>Buku</h2>
            <div class="cards">
                <?php
                $result = mysqli_query($conn, "SELECT * FROM buku");
                if ($result && mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        
                        if ($row['cover']) {
                            $cover_path = '../assets/cover/' . $row['cover'];
                        } else {
                            $cover_path = 'https://via.placeholder.com/180x150?text=No+Cover';
                        }
                        $bukuData = json_encode([
                            'judul' => $row['judul_buku'],
                            'pengarang' => $row['pengarang'],
                            'penerbit' => $row['penerbit'],
                            'tahun' => $row['tahun_terbit'],
                            'stok' => $row['stok'],
                            'sinopsis' => $row['sinopsis'] ?? '',
                            'cover' => $cover_path,
                            'id' => $row['id_buku']
                        ]);
                ?>
                <div class="card" onclick="openBookDetail(this)" data-book='<?php echo htmlspecialchars($bukuData, ENT_QUOTES, 'UTF-8'); ?>' style="cursor: pointer;">
                    <img src="<?php echo $cover_path; ?>" alt="<?php echo $row['judul_buku']; ?>">
                    <h4><?php echo substr($row['judul_buku'], 0, 18); ?></h4>
                    <p><strong><?php echo $row['pengarang']; ?></strong></p>
                    <p>Stok: <span style="color: #dc3545; font-weight: bold;"><?php echo $row['stok']; ?></span></p>
                </div>

                
                <?php 
                    }
                } else {
                    echo "<p style='color: #999;'>Belum ada data buku</p>";
                }
                ?>
            </div>
        </div>

        <!-- Book Detail Modal -->
        <div id="bookDetailModal">
            <div class="book-detail-container">
                <div class="book-detail-cover">
                    <img id="bookCover" src="" alt="Book Cover">
                </div>
                <div class="book-detail-info">
                    <h2 id="bookTitle">-</h2>
                    <div class="detail-item">
                        <div class="detail-label">Pengarang</div>
                        <div class="detail-value" id="bookAuthor">-</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Penerbit</div>
                        <div class="detail-value" id="bookPublisher">-</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Tahun Terbit</div>
                        <div class="detail-value" id="bookYear">-</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Stok Tersedia</div>
                        <div class="detail-value" id="bookStock">-</div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Deskripsi</div>
                        <div class="book-detail-synopsis" id="bookSynopsis">-</div>
                    </div>
                    <div class="book-detail-actions">
                        <button class="close-detail-btn" onclick="closeBookDetail()">Tutup</button>
                    </div>
                </div>
            </div>
        </div>

        <script src="../assets/js/script.js"></script>
    </body>
    </html>
