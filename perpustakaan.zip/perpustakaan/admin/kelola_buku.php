<?php
include '../login/config.php';
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user'] != 'admin') {
    header('Location: ../login/index.php');
    exit;
}

$search = '';
if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
}

$upload_dir = '../assets/cover/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['tambah_buku'])) {
    $kode = $_POST['kode_buku'];
    $judul = $_POST['judul_buku'];
    $pengarang = $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun = $_POST['tahun_terbit'];
    $stok = $_POST['stok'];
    $sinopsis = isset($_POST['sinopsis']) ? mysqli_real_escape_string($conn, $_POST['sinopsis']) : '';
    $cover_file = '';
    
    
    if (isset($_FILES['cover']) && $_FILES['cover']['error'] == 0) {
        $file = $_FILES['cover'];
        $file_name = $file['name'];
        $file_tmp = $file['tmp_name'];
        $file_size = $file['size'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
       
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($file_ext, $allowed) && $file_size <= 5000000) { 
            $new_file_name = uniqid() . '.' . $file_ext;
            if (move_uploaded_file($file_tmp, $upload_dir . $new_file_name)) {
                $cover_file = $new_file_name;
            } else {
                $error = "Gagal upload file!";
            }
        } else {
            $error = "Tipe file tidak diizinkan atau ukuran terlalu besar!";
        }
    }
    
    if (!isset($error)) {
        $cover_value = $cover_file ? "'$cover_file'" : "NULL";
        $sinopsis_value = $sinopsis ? "'$sinopsis'" : "NULL";
        $query = "INSERT INTO buku (kode_buku, judul_buku, pengarang, penerbit, tahun_terbit, stok, cover, sinopsis) VALUES ('$kode', '$judul', '$pengarang', '$penerbit', '$tahun', '$stok', $cover_value, $sinopsis_value)";
        if (mysqli_query($conn, $query)) {
            $success = "Buku berhasil ditambahkan!";
        } else {
            $error = "Gagal menambahkan buku: " . mysqli_error($conn);
        }
    }
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_buku'])) {
    $id = $_POST['id_buku'];
    $kode = $_POST['kode_buku'];
    $judul = $_POST['judul_buku'];
    $pengarang = $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun = $_POST['tahun_terbit'];
    $stok = $_POST['stok'];
    $sinopsis = isset($_POST['sinopsis']) ? mysqli_real_escape_string($conn, $_POST['sinopsis']) : '';
    $query_old = "SELECT cover FROM buku WHERE id_buku = '$id'";
    $result_old = mysqli_query($conn, $query_old);
    $old_cover = '';
    if ($result_old && mysqli_num_rows($result_old) > 0) {
        $row_old = mysqli_fetch_assoc($result_old);
        $old_cover = $row_old['cover'];
    }
    
    $cover_file = $old_cover; 
    
    
    if (isset($_FILES['cover']) && $_FILES['cover']['error'] == 0) {
        $file = $_FILES['cover'];
        $file_name = $file['name'];
        $file_tmp = $file['tmp_name'];
        $file_size = $file['size'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($file_ext, $allowed) && $file_size <= 5000000) {
            $new_file_name = uniqid() . '.' . $file_ext;
            if (move_uploaded_file($file_tmp, $upload_dir . $new_file_name)) {
               
                if ($old_cover && file_exists($upload_dir . $old_cover)) {
                    unlink($upload_dir . $old_cover);
                }
                $cover_file = $new_file_name;
            } else {
                $error = "Gagal upload file!";
            }
        } else {
            $error = "Tipe file tidak diizinkan atau ukuran terlalu besar!";
        }
    }
    
    if (!isset($error)) {
        $cover_value = $cover_file ? "'$cover_file'" : "NULL";
        $sinopsis_value = $sinopsis ? "'$sinopsis'" : "NULL";
        $query = "UPDATE buku SET kode_buku='$kode', judul_buku='$judul', pengarang='$pengarang', penerbit='$penerbit', tahun_terbit='$tahun', stok='$stok', cover=$cover_value, sinopsis=$sinopsis_value WHERE id_buku=$id";
        if (mysqli_query($conn, $query)) {
            $success = "Buku berhasil diupdate!";
        } else {
            $error = "Gagal mengupdate buku: " . mysqli_error($conn);
        }
    }
}


if (isset($_GET['hapus_buku'])) {
    $id = $_GET['hapus_buku'];
    
    
    $query_cover = "SELECT cover FROM buku WHERE id_buku = $id";
    $result_cover = mysqli_query($conn, $query_cover);
    if ($result_cover && mysqli_num_rows($result_cover) > 0) {
        $row_cover = mysqli_fetch_assoc($result_cover);
        $cover_file = $row_cover['cover'];
    }
    
    $query = "DELETE FROM buku WHERE id_buku=$id";
    if (mysqli_query($conn, $query)) {
        
        if (isset($cover_file) && $cover_file && file_exists($upload_dir . $cover_file)) {
            unlink($upload_dir . $cover_file);
        }
        $success = "Buku berhasil dihapus!";
    } else {
        $error = "Gagal menghapus buku: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Buku - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="sidebar">
        <h2>Lumina Archive</h2>
        <a href="dashboard.php">Home</a>
        <a href="kelola_buku.php" class="active">Kelola Buku</a>
        <a href="kelola_anggota.php">Kelola Anggota</a>
        <a href="laporan.php">Laporan</a>
        <a href="../login/logout.php">Logout</a>
    </div>

    <div class="content">
        <?php if (isset($success)) echo "<div class='success'>$success</div>"; ?>
        <?php if (isset($error)) echo "<div class='error'>$error</div>"; ?>

        <h1>Kelola Buku</h1>
        <button class="btn btn-tambah" onclick="showModal('tambah-buku')">+ Tambah Buku</button>

        <h2 style="margin-top: 30px;">Daftar Buku</h2>
     
        <table>
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Judul</th>
                <th>Pengarang</th>
                <th>Penerbit</th>
                <th>Tahun</th>
                <th>Stok</th>
                <th>Aksi</th>
            </tr>
            <?php
            $search_clause = '';
            if ($search !== '') {
                $search_term = mysqli_real_escape_string($conn, $search);
                $search_clause = "WHERE kode_buku LIKE '%$search_term%' OR judul_buku LIKE '%$search_term%' OR pengarang LIKE '%$search_term%' OR penerbit LIKE '%$search_term%'";
            }
            $result = mysqli_query($conn, "SELECT * FROM buku $search_clause ORDER BY judul_buku ASC");
            if ($result && mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <tr>
                <td><?php echo $row['id_buku']; ?></td>
                <td><?php echo $row['kode_buku']; ?></td>
                <td><?php echo $row['judul_buku']; ?></td>
                <td><?php echo $row['pengarang']; ?></td>
                <td><?php echo $row['penerbit']; ?></td>
                <td><?php echo $row['tahun_terbit']; ?></td>
                <td><?php echo $row['stok']; ?></td>
                <td>
                    <button class="btn btn-edit" onclick="editBuku(<?php echo htmlspecialchars(json_encode($row)); ?>)">Edit</button>
                    <a href="kelola_buku.php?hapus_buku=<?php echo $row['id_buku']; ?>" class="btn btn-delete" onclick="return confirm('Yakin hapus buku ini?')">Hapus</a>
                </td>
            </tr>
            <?php
                }
            } else {
                echo "<tr><td colspan='7' style='text-align: center; color: #999;'>Belum ada data buku</td></tr>";
            }
            ?>
        </table>
    </div>

    
    <div id="tambah-buku" class="modal">
        <div class="modal-content">
            <style>
                .modal-content {
                    background: radial-gradient(circle at top left, rgba(131, 197, 255, 0.16), transparent 18%), radial-gradient(circle at bottom right, rgba(255, 117, 199, 0.14), transparent 18%), linear-gradient(180deg, #120d23 0%, #1f173a 100%);
                    color: #f4f5ff;
                }
                
            </style>
            <div class="modal-header">
                <h2>Tambah Buku</h2>
                <span class="close-btn" onclick="closeModal('tambah-buku')">&times;</span>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Kode Buku</label>
                    <input type="text" name="kode_buku" required>
                </div>
                <div class="form-group">
                    <label>Judul Buku</label>
                    <input type="text" name="judul_buku" required>
                </div>
                <div class="form-group">
                    <label>Pengarang</label>
                    <input type="text" name="pengarang" required>
                </div>
                <div class="form-group">
                    <label>Penerbit</label>
                    <input type="text" name="penerbit" required>
                </div>
                <div class="form-group">
                    <label>Tahun Terbit</label>
                    <input type="number" name="tahun_terbit" min="1900" max="2099" required>
                </div>
                <div class="form-group">
                    <label>Stok</label>
                    <input type="number" name="stok" min="0" required>
                </div>
                <div class="form-group">
                    <label>Sinopsis / Deskripsi</label>
                    <textarea name="sinopsis" rows="4" placeholder="Masukkan sinopsis atau deskripsi buku..."></textarea>
                </div>
                <div class="form-group">
                    <label>Upload Cover (JPG/PNG/GIF, max 5MB)</label>
                    <input type="file" name="cover" accept="image/jpeg,image/png,image/gif">
                </div>
                <button type="submit" name="tambah_buku" class="btn btn-tambah">Simpan</button>
            </form>
        </div>
    </div>

   
    <div id="edit-buku" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Edit Buku</h2>
                <span class="close-btn" onclick="closeModal('edit-buku')">&times;</span>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" id="edit_id_buku" name="id_buku">
                <div class="form-group">
                    <label>Kode Buku</label>
                    <input type="text" id="edit_kode_buku" name="kode_buku" required>
                </div>
                <div class="form-group">
                    <label>Judul Buku</label>
                    <input type="text" id="edit_judul_buku" name="judul_buku" required>
                </div>
                <div class="form-group">
                    <label>Pengarang</label>
                    <input type="text" id="edit_pengarang" name="pengarang" required>
                </div>
                <div class="form-group">
                    <label>Penerbit</label>
                    <input type="text" id="edit_penerbit" name="penerbit" required>
                </div>
                <div class="form-group">
                    <label>Tahun Terbit</label>
                    <input type="number" id="edit_tahun_terbit" name="tahun_terbit" min="1900" max="2099" required>
                </div>
                <div class="form-group">
                    <label>Stok</label>
                    <input type="number" id="edit_stok" name="stok" min="0" required>
                </div>
                <div class="form-group">
                    <label>Sinopsis / Deskripsi</label>
                    <textarea id="edit_sinopsis" name="sinopsis" rows="4" placeholder="Masukkan sinopsis atau deskripsi buku..."></textarea>
                </div>
                <div class="form-group">
                    <label>Upload Cover Baru (kosongkan jika tidak ingin mengubah)</label>
                    <input type="file" name="cover" accept="image/jpeg,image/png,image/gif">
                </div>
                <button type="submit" name="edit_buku" class="btn btn-tambah">Update</button>
            </form>
        </div>
    </div>
                
        

    <script>
        function showModal(id) {
            document.getElementById(id).classList.add('show');
        }
        function closeModal(id) {
            document.getElementById(id).classList.remove('show');
        }
        function editBuku(data) {
            document.getElementById('edit_id_buku').value = data.id_buku;
            document.getElementById('edit_kode_buku').value = data.kode_buku;
            document.getElementById('edit_judul_buku').value = data.judul_buku;
            document.getElementById('edit_pengarang').value = data.pengarang;
            document.getElementById('edit_penerbit').value = data.penerbit;
            document.getElementById('edit_tahun_terbit').value = data.tahun_terbit;
            document.getElementById('edit_stok').value = data.stok;
            document.getElementById('edit_sinopsis').value = data.sinopsis || '';
            showModal('edit-buku');
        }
        window.onclick = function(e) {
            if (e.target.classList.contains('modal')) {
                e.target.classList.remove('show');
            }
        }
    </script>

    <script src="../assets/js/script.js"></script>
</body>
</html>
                
