// Simple JavaScript for Perpustakaan System

// Confirm actions
function confirmAction(message) {
    return confirm(message);
}

// Auto-hide alerts after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    // Add any initialization code here

    // Example: Add loading animation for buttons
    const buttons = document.querySelectorAll('.btn-pinjam, .btn-kembali, .btn-berhentikan');
    buttons.forEach(button => {
        button.addEventListener('click', function() {
            if (this.classList.contains('btn-pinjam')) {
                this.innerHTML = '⏳ Memproses...';
            } else if (this.classList.contains('btn-kembali')) {
                this.innerHTML = '⏳ Mengembalikan...';
            } else if (this.classList.contains('btn-berhentikan')) {
                this.innerHTML = '⏳ Memproses...';
            }
        });
    });

    // Add smooth scrolling for sidebar links
    const sidebarLinks = document.querySelectorAll('.sidebar a');
    sidebarLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // Remove active class from all links
            sidebarLinks.forEach(l => l.classList.remove('active'));
            // Add active class to clicked link
            this.classList.add('active');
        });
    });

    // Highlight current page in sidebar
    const currentPath = window.location.pathname;
    sidebarLinks.forEach(link => {
        if (link.getAttribute('href') && currentPath.includes(link.getAttribute('href'))) {
            link.classList.add('active');
        }
    });
});

// Simple form validation for registration
function validateRegistration() {
    const nama = document.getElementById('nama').value;
    const nis = document.getElementById('nis').value;
    const kelas = document.getElementById('kelas').value;
    const password = document.getElementById('password').value;

    if (!nama || !nis || !kelas || !password) {
        alert('Semua field harus diisi!');
        return false;
    }

    if (nis.length < 5) {
        alert('NIS minimal 5 karakter!');
        return false;
    }

    if (password.length < 6) {
        alert('Password minimal 6 karakter!');
        return false;
    }

    return true;
}

// Simple search functionality for books
function searchBooks() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const cards = document.querySelectorAll('.card');

    cards.forEach(card => {
        const title = card.querySelector('h4').textContent.toLowerCase();
        const author = card.querySelector('p').textContent.toLowerCase();

        if (title.includes(searchTerm) || author.includes(searchTerm)) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

// Add some visual feedback
function showMessage(message, type = 'info') {
    // Create message element
    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${type}`;
    msgDiv.textContent = message;

    // Style the message
    msgDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 5px;
        color: white;
        font-weight: bold;
        z-index: 1000;
        animation: slideIn 0.3s ease;
    `;

    if (type === 'success') {
        msgDiv.style.backgroundColor = '#27ae60';
    } else if (type === 'error') {
        msgDiv.style.backgroundColor = '#e74c3c';
    } else {
        msgDiv.style.backgroundColor = '#3498db';
    }

    // Add to body
    document.body.appendChild(msgDiv);

    // Remove after 3 seconds
    setTimeout(() => {
        msgDiv.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(msgDiv);
        }, 300);
    }, 3000);
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }

    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }

    .sidebar a.active {
        background: rgba(255,255,255,0.3);
        border-left: 4px solid white;
    }

    .message {
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
`;
document.head.appendChild(style);


function bukaBuku(judul, penulis, file) {
    document.getElementById("modalBuku").style.display = "block";
    document.getElementById("judulBuku").innerText = judul;
    document.getElementById("penulisBuku").innerText = penulis;

    // tampilkan PDF / file buku
    document.getElementById("viewerBuku").src = "file_buku/" + file;
}

function tutupBuku() {
    document.getElementById("modalBuku").style.display = "none";
}

function bukaBukuDashboard(judul, penulis, file) {
    document.getElementById("modalBukuDashboard").style.display = "block";
    document.getElementById("judulBukuDashboard").innerText = judul;
    document.getElementById("penulisBukuDashboard").innerText = penulis;

    // tampilkan file PDF dari folder
    document.getElementById("viewerBukuDashboard").src = "file_buku/" + file;
}

function tutupBukuDashboard() {
    document.getElementById("modalBukuDashboard").style.display = "none";
}

// Buka modal detail buku
function openBookDetail(element) {
    try {
        const bookDataString = element.getAttribute('data-book');
        if (!bookDataString) {
            console.error('Data buku tidak ditemukan');
            return;
        }
        
        const bukuData = JSON.parse(bookDataString);
        const modal = document.getElementById("bookDetailModal");
        
        if (!modal) {
            console.error('Modal tidak ditemukan');
            return;
        }
        
        // Set data ke dalam modal
        document.getElementById("bookTitle").textContent = bukuData.judul || '-';
        document.getElementById("bookAuthor").textContent = bukuData.pengarang || '-';
        document.getElementById("bookPublisher").textContent = bukuData.penerbit || '-';
        document.getElementById("bookYear").textContent = bukuData.tahun || '-';
        document.getElementById("bookStock").textContent = bukuData.stok || '-';
        document.getElementById("bookSynopsis").textContent = bukuData.sinopsis || "Tidak ada deskripsi tersedia";
        
        const coverImg = document.getElementById("bookCover");
        if (coverImg && bukuData.cover) {
            coverImg.src = bukuData.cover;
        }
        
        // Tampilkan modal
        modal.classList.add("show");
    } catch (error) {
        console.error('Error membuka detail buku:', error);
        alert('Terjadi kesalahan saat membuka detail buku');
    }
}

// Tutup modal detail buku
function closeBookDetail() {
    const modal = document.getElementById("bookDetailModal");
    if (modal) {
        modal.classList.remove("show");
    }
}

// Tutup modal saat klik di luar konten
document.addEventListener('click', function(event) {
    const modal = document.getElementById("bookDetailModal");
    if (modal && event.target === modal) {
        closeBookDetail();
    }
});
